sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{downloadNow:function(n){debugger;e.show("Custom handler invoked.")}}});
//# sourceMappingURL=DownloadButtonController.js.map